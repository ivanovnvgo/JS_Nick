'use strict';
// 1. получите все кнопки и сохраните в переменную
let btns = document.querySelectorAll('button');
// 1.1 затем проитерируйтесь по кнопкам и каждой из
btns.forEach(function (button) {
    button.addEventListener('click', function (event) {
        console.log('Прослушивание кнопкам назначено');
        // них добавьте обработчик клика - функцию handleClick
        handleClick(event);
    });
});
/**
 * Функция обрабатывает клик по кнопке в карточке товара и попеременно вызывает
 * функции для показа или скрытия текста о товаре.
 * @param {MouseEvent} clickedButtonEvent 
 */
function handleClick(clickedButtonEvent) {
    console.log('Вход в функцию handleClick');
    // 2. из объекта события получите ссылку на .product и
    // сохраните в переменную:
    // const cardNode = ;
    const cardNode = clickedButtonEvent.target.parentNode;

    // 3. создайте литерал объекта со следующими свойствами:
    const card = {
        wrap: cardNode, // здесь элемент с классом .product
        img: cardNode.querySelector('img'), // здесь картинка внутри .product
        productName: cardNode.querySelector('.productName'), // здесь .productName, который внутри .product
        button: cardNode.querySelector('button'), // здесь button, который внутри .product
    };

    // 4. получаем текст на кнопке, которая внутри .product
    let text_button = card.button.textContent;
    console.log(text_button);
    if (text_button === "Подробнее") { // 4.1 проверяем равняется ли этот текст строке "Подробнее"
        // 4.2 если да, то передаем объект card в функцию showMoreText
        showMoreText(card);
    } else if (text_button === "Отмена") { // 4.3 проверяем равняется ли текст на кнопке строке "Отмена"
        // 4.4 если да, то передаем объект card в функцию hideMoreText
        hideMoreText(card);
    }
}

/**
 * Функция скрывает текст с описанием товара.
 * @param {Object} card 
 * @param {HTMLDivElement} card.wrap
 * @param {HTMLImageElement} card.img
 * @param {HTMLDivElement} card.productName
 * @param {HTMLButtonElement} card.button
 */
function hideMoreText(card) {
    // 5. картинке внутри .product ставим стиль display: block
    card.img.style.display = 'block';
    // 5.1 внутри .product находим элемент с классом .desc 
     card.wrap.querySelector('.desc').remove();
    
    //??????? !!!!! Посмотрите, пожалуйста, мой код в коментарии  
    /*let searchClassDesc = document.querySelector('.desc');
    //и удаляем его
    searchClassDesc.remove();
    */
    //У меня вопрос к моему коду: я прошел кликами по всем кнопкам, код везде сработал, если я слева направо снова кликами прохожу все кнопки (как бы "отжимаю"), то код снова работает правильно, но если я начинаю кликать по кнопкам справа налево (как бы отжимать нажатые ранее кнопки), то на крайнем правом div'e картинка появляется, а текстовый div не исчезает, он исчезнет только после того, как "отожмутся в первоначальное положение" все кнопки 
    
   
    // 5.2 кнопке, которая внутри .product ставим текст "Подробнее"
    card.button.innerHTML = 'Подробнее';
}

/**
 * Функция показывает текст с описанием товара.
 * @param {Object} card 
 * @param {HTMLDivElement} card.wrap
 * @param {HTMLImageElement} card.img
 * @param {HTMLDivElement} card.productName
 * @param {HTMLButtonElement} card.button 
 */
function showMoreText(card) {
    console.log('Вход в функцию showMoreText');
    // 6. картинке внутри .product ставим display: none
    card.img.style.display = 'none';
    // 6.1 сохраняем произвольный текст в переменную
    const changeText = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. In, ad.';
    // 6.2 внутри .product есть .productName, после него вставляем div.desc и текстом из переменной из п. 6.1
    let newDiv_desc = `<div class="desc">${changeText}</div>`;
    card.productName.insertAdjacentHTML('afterend', newDiv_desc);
    // 6.3 внутри .product у кнопки текст ставим "Отмена"
    card.button.innerHTML = 'Отмена';
}
