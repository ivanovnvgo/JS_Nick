'use strict';
const texts = {
    text1: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.',
    text2: 'Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты.',
    text3: 'Проснувшись однажды утром после беспокойного сна, Грегор Замза обнаружил.'
};

/*
    Задание. Нужно сделать, чтобы при кликах по .nav-link:
    1. Класс active назначался тому .nav-link, по которому кликнули, а у предыдущего
    .nav-link, чтобы этот класс убирался.
    2. В зависимости от того по какому .nav-link кликнули нужно чтобы менялся текст
    в .text, соответствующие тексты вы найдете в app.js
*/

/* 
1. Получите ссылку на .text, например с помощью querySelector
2. Получите коллекцию, в которой хранятся все .nav-link, например с помощью querySelectorAll
    2.1 Переберите полученную коллекцию, например с помощью forEach, и каждой ссылке назначьте
    обработчик клика функцию clickHandler.
*/
let text = document.querySelector('.text');
let links = document.querySelectorAll('.nav-link');
links.forEach(function(links_nav) {
    links_nav.addEventListener('click', clickHandler);
});

/**
 * Обработчик клика по .nav-link
 * @param {MouseEvent} event 
 */
function clickHandler(event) {
    // здесь вызывайте changeText и changeActiveClass, и передавайте
    // им объект события.
    changeActiveClass(event);
    changeText(event);

}

/**
 * Эта функция должна убирать .active у предыдущего .nav-link и ставить его
 * на тот, по которому кликнули.
 * @param {MouseEvent} event 
 */
function changeActiveClass(event) {
    let event_i = document.querySelector('.active');
    event_i.classList.remove('active');
    event.target.classList.add('active');

}

/**
 * Эта фукнция должна читать текст (например через textContent) из 
 * .nav-link по которому кликнули и в зависимости от этого в .text
 * ставить соответствующий текст из texts.
 * @param {MouseEvent} event 
 */
function changeText(event) {
    let nav_link_i = event.target.textContent;
    if (nav_link_i === "Link 1") {
        text.textContent = texts.text1;
    } else
    if (nav_link_i === "Link 2") {
        text.textContent = texts.text2;
    } else
    if (nav_link_i === "Link 3") {
        text.textContent = texts.text3;
    }
}
